const express = require("express");
const path = require("path");
const cors = require("cors");
const app = express();
const mongoose = require("mongoose");
const multer = require("multer");
// use
app.use(express.static(path.join(__dirname, 'public')))
app.use(express.urlencoded({ extended: true }));
app.use(cors());
app.use(express.json());
// imports 
const {
  main,
  signup,
  login,
  auth,
  updateProfile,
  getUserInfo,
  getAllUsers,
  updateProfilePic,
  deleteUser
} = require("./app/controllers/user.controllers");
const {
  addCourse,
  addPDF,
  updateCourse,
  getAllCourses,
  deleteCourse,
  getCourseInfo,
} = require("./app/controllers/course.controllers");
const { promise } = require("bcrypt/promises");
const { ok } = require("assert");
const { userModel } = require("./app/models/user");
const { adminModel } = require("./app/models/admin");

// storage for files
// note that I have specified the path "uploads/images" to store the uploaded images to the server
// since we are not using AWS we are storing the uploaded files in the server itself
const imgStorage = multer.diskStorage({
  destination: function (request, file, callback) {
    callback(null, "./uploads/images");
  },
  // we are adding a timestamp to the name of the uploaded file to make it unique
  filename: function (request, file, callback) {
    callback(null, Date.now() + file.originalname);
  },
});
// here we are specifying the storage object and limiting the size of the file to be 3MB but you can change that as you like
const imgUpload = multer({
  storage: imgStorage,
  limits: {
    fieldSize: 1024 * 1024 * 3,
  },
});

////////////
// this is the storage setup for the pdf file of each course, they will be stored in the path "./uploads/pdfs"
const courseStorage = multer.diskStorage({
  destination: function (request, file, callback) {
    callback(null, "./uploads/pdfs");
  },
  // we are adding a timestamp to the name of the uploaded file to make it unique
  filename: function (request, file, callback) {
    callback(null, Date.now() + file.originalname);
  },
});
// the size is set to 100MB but you can change this
const courseUpload = multer({
  storage: courseStorage,
  limits: {
    fieldSize: 1024 * 1024 * 100,
  },
});
// Initiating the connection to the mongo database
// now it is local, but you can connect it to Mongo Atalas and have a production ready database
// all you need to do is to go to mongo atalas website and create an account then get the link to the new data base
mongoose.connect("mongodb://localhost:27017/app");
const connection = mongoose.connection;
connection.once("open", () => console.log("Database connection established."));

// endpoints
// 1. the default endpoint which indicated that the server is working
// just go to http://localhost:8080/ to test that the server is working
// you can also use thunderclient vs code extension as you can also use postman

app.post("/updateprofileimage", imgUpload.single("image"), updateProfilePic);
app.post("/login", login);
app.post("/signup", signup);
app.get("/getuserinfo", getUserInfo);
app.get("/getallusers", getAllUsers);
app.delete("/deleteuser/:id", deleteUser)
app.put("/updateprofile/:userName", updateProfile);
app.post("/addcourse", addCourse);
app.post("/addcoursepdf", courseUpload.single("coursePDF"), addPDF);
app.put("/updatecourse/:courseName", updateCourse);
app.get("/allcourses", getAllCourses);
app.delete("/deletecourse/:courseName", deleteCourse);
app.get("/courseinfo", getCourseInfo);
app.post("/login-admin", async (req, res) => {
  try {
    const { userName, password } = req.body;
    const admin = await adminModel.findOne({
      userName,
      password
    });

    if (admin?.userName) {
      res.send({
        status: 'ok', data: {
          token: 'admin-token',
          role: 'Admin',
          userName,
        }
      });
    } else {
      res.send({ message: 'Invalid username and/or password!' });
    }
  } catch (error) {
    res.send({ message: error.message });
  }
});

app.get("/user-count-per-role", async (req, res) => {
  try {
    const [students, teachers, parents] = await Promise.all([
      userModel.count({ role: 'Student' }),
      userModel.count({ role: 'Teacher' }),
      userModel.count({ role: 'Parent' }),
    ]);

    res.send({ status: 'ok', students, teachers, parents });
  } catch (error) {
    res.send({ message: error.message });
  }
})
app.listen(8080, () => console.log("Server is up and running at port 8080."));
