function logout() { // call on logout button
    localStorage.clear();
    window.location.href = '/SignUp.html';
}