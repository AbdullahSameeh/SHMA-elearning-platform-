async function getCourseInfo() {
    try {
        const grades = document.querySelector('#grades');
        const enroll = document.querySelector('#enroll');
        const courseName = params.courseName;
        const courseNameInp = document.querySelector('#course-name');
        const creatorName = document.querySelector('#creator-name');
        const creatorIntro = document.querySelector('#intro');
        const creatorImage = document.querySelector('#creator-image');
        const backgroundImage = document.querySelector('#bg-image');
        const link = document.querySelector('#link');
        const response = await fetch(`/courseinfo?courseName=${courseName}`);
        const payload = await response.json();
        grades.innerHTML = '';
        enroll.innerHTML = '<h2>Courses</h2>';

        for (let i = 1; i <= 12; ++i) {
            grades.innerHTML += `<li><a href="#">${payload.result.courseName} for grade ${i} <span></span></a></li>`;
            enroll.innerHTML += `
            <div id="comment-${i}" class="comment">
                  <div class="d-flex">
                    <div class="comment-img"><img src="assets/img/blog/comments-1.jpg" alt=""></div>
                    <div>
                      <h5>${payload.result.courseName} for grade ${i} <a href="#" class="reply"><i class="bi bi-reply-fill"></i> enroll</a></h5>
                    </div>
                  </div>
                </div>`;
        }

        console.log(payload);
        if (payload.status === 'ok') {
            // success
            courseNameInp.textContent = payload.result.courseName;
            creatorIntro.textContent = payload.result.creatorIntro;
            creatorName.textContent = payload.result.courseCreator;
            backgroundImage.src = payload.result.backgroundImage;
            creatorImage.src = payload.result.creatorPhoto || payload.result.backgroundImage;
            link.innerHTML = payload.result.courseLink || `<iframe width="560" height="315" src="https://www.youtube.com/embed/6pXvTXAGrQk" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>`;
        }
    } catch (error) {
        alert(error.message);
    }
}

getCourseInfo();
