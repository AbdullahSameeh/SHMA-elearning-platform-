const submitBtn = document.querySelector('#inp-submit');
const form = document.querySelector('#form');
form.addEventListener('sumbit', (e) => e.preventDefault());

async function addCourse() {
    try {
        const name = document.querySelector('#name').value.trim();
        const link = document.querySelector('#link').value;
        const creator = document.querySelector('#creator').value;
        const image = document.querySelector('#image').value;
        const creatorIntro = document.querySelector('#intro').value;
        const creatorPhoto = document.querySelector('#creator-image').value;

        // creatorIntro
        // creatorPhoto
        // coursePDF: { type: String, default: "" },
        const data = {
            courseName: name,
            courseLink: link,
            courseCreator: creator,
            backgroundImage: image,
            creatorIntro,
            creatorPhoto
        };
        const respnose = await fetch('/addcourse', {
            headers: {
                'Content-Type': 'application/json'
            },
            method: 'POST',
            body: JSON.stringify(data),
        });

        const payload = await respnose.json();
        console.log(payload);
        if (payload.status === 'ok') {
            // success
            window.location.href = '/Courses.html';
        } else {
            alert(payload.message);
        }
    } catch (error) {
        alert(error.message);
    }
}

submitBtn.addEventListener('click', (e) => {
    e.preventDefault();
    addCourse();
})