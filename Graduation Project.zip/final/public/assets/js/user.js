async function getUserInfo() {
    const username = params.username;
    const fullName = document.querySelector('#full-name'); 
    const fullNameLeft = document.querySelector('#full-name-left'); 
    const role = document.querySelector('#role');
    const school = document.querySelector('#school');
    const phone = document.querySelector('#phone');
    const email = document.querySelector('#email');
    const img = document.querySelector('#img');
    const birthdate = document.querySelector('#birthdate');
    const gender = document.querySelector('#gender');
    const address = document.querySelector('#address');

    try {
        const response = await fetch(`/getuserinfo?userName=${username}`);
        const payload = await response.json();
        if (payload.status === 'ok') {
            fullName.textContent = `${payload.result.firstName} ${payload.result.lastName}`;
            fullNameLeft.textContent = `${payload.result.firstName} ${payload.result.lastName}`;
            school.textContent = payload.result.school || "Not Provided";
            phone.textContent = payload.result.phoneNumber || "Not Provided";
            email.textContent = payload.result.email || "Not Provided";
            gender.textContent = payload.result.gender;
            address.textContent = payload.result.address || "Not Provided";
            birthdate.textContent = payload.result.birthdate ? new Date(payload.result.birthdate).toLocaleDateString() : "Not Provided";
            img.src = payload.result.img || "https://bootdey.com/img/Content/avatar/avatar7.png";
        } else {
            window.location.href = '/';
        }
    } catch (error) {
        alert(error.message)   
    }
}

getUserInfo();