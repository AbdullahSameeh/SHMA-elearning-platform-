const loginBtn = document.querySelector('#login');

const userLogin = async (username, password) => {
    try {
        const data = {
            userName: username,
            password: password
        };
        const response = await fetch('/login', {
            headers: {
                'Content-Type': 'application/json'
            },
            method: 'POST',
            body: JSON.stringify(data)
        });

        const body = await response.json();
        if (body.status === 'ok') {
            // success
            localStorage.setItem('token', body.data.token);
            localStorage.setItem('username', body.data.userName);
            localStorage.setItem('role', body.data.role);
            window.location.href = '/';
        } else {
            alert(body.message)
        }

    } catch (error) {
        alert(error.message)
    }
};

const adminLogin = async (username, password) => {
    try {
        console.log(username, password);
        const data = {
            userName: username,
            password: password
        };
        const response = await fetch('/login-admin', {
            headers: {
                'Content-Type': 'application/json'
            },
            method: 'POST',
            body: JSON.stringify(data)
        });

        const body = await response.json();
        if (body.status === 'ok') {
            // success
            localStorage.setItem('token', body.data.token);
            localStorage.setItem('username', body.data.userName);
            localStorage.setItem('role', body.data.role);
            window.location.href = '/AdminPanel.html';
        } else {
            alert(body.message)
        }

    } catch (error) {
        alert(error.message)
    }
};

const loginHandler = async () => {
    console.log('hello')
    const username = document.querySelector('#login-username');
    const password = document.querySelector('#login-password');
   
    if (username?.value?.startsWith('@')) {
        adminLogin(username.value.slice(1), password.value);
    } else {
        userLogin(username.value, password.value);
    }
};

loginBtn.addEventListener('click', loginHandler);