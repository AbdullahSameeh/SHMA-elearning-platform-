const courses = document.querySelector('#courses');

async function getAllCourses() {
    try {
        const response = await fetch('/allcourses');
        const payload = await response.json();
        payload.forEach((course) => {
            const holder = `
        <article class="entry">

            <div class="entry-img">
              <img src="${course.backgroundImage}" alt="" class="img-fluid">
            </div>

            <h2 class="entry-title">
              ${course.courseName}
            </h2>

            <div class="entry-content">
              <div class="read-more">
                <a href="/class.html?courseName=${course.courseName}">View Course</a>
              </div>
            </div>

          </article>`;
            courses.innerHTML += holder;
        })
        console.log(payload);
    } catch (error) {
        alert(error.message);
    }
}

getAllCourses();