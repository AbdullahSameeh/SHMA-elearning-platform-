const Firstname = document.querySelector("#sign-up-firstname");
const Lastname  = document.querySelector("#sign-up-lastname");
const Email = document.querySelector("#sign-up-email");
const Role = document.querySelector("#sign-up-role");
const Gender = document.querySelector("#sign-up-gender");
const Username = document.querySelector("#sign-up-username");
const Password = document.querySelector("#sign-up-password");
const ConfirmPassword = document.querySelector("#sign-up-confirm-password");
const SignUpBtn = document.querySelector("#sign-up");


const nameValidation = /^[A-Za-z_-]+$/;
const emailValidation = /^(([^<>()[\]\.,;:\s@\"]+(\.[^<>()[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i;
const nationalValidation = /^([9][0-9]{2}[12][0][0-9]{5})|([2][0]{2}[0-9]{7})$/;
const phoneValidation = /^(009627|9627|\+9627|07)(7|8|9)([0-9]{7})$/;


function redBorder(element) {
    element.classList.remove('green-border');
    element.classList.add('red-border');
}

function greenBorder(element) {
    element.classList.remove('red-border');
    element.classList.add('green-border');
}

function disabled () {
    SignUpBtn.classList.remove('not-disabled');
    SignUpBtn.classList.add('disabled');
}

function notDisabled(){
    SignUpBtn.classList.remove('disabled');
    SignUpBtn.classList.add('not-disabled');
}


function disableButton() {
    if(Firstname.value.length === 0 || Firstname.value.length < 3 || Firstname.value.length > 20 ){
        disabled();
    }else if(Lastname.value.length === 0 || Lastname.value.length < 3 || Lastname.value.length > 20 ){
        disabled();
    } else if(Email.value.length === 0 || !Email.value.match(emailValidation)){
        disabled();
    } else if (Password.value.length === 0 || Password.value.length < 6 ){
        disabled();
    } else if (ConfirmPassword.value.length === 0 || ConfirmPassword.value != Password.value ){
        disabled();
    } else if(Gender.value === ""){
        disabled();
    } else if(Role.value === ""){
        disabled();
    } else {
        notDisabled();
    }
};

disableButton();

function firstLastNameValidator(element) {
    if (element.value.length < 3 || element.value.length > 20) {
        redBorder(element);
        disableButton();
    } else if (!element.value.match(nameValidation)) {
        redBorder(element);
        disableButton();
    } else {
        greenBorder(element);
        disableButton();
    }
}

function emailValidator(element) {
    if (element.value.length === 0) {
        redBorder(element)
        disableButton();
    } else if (!element.value.match(emailValidation)) {
        redBorder(element);
        disableButton();
    } else {
        greenBorder(element)
        disableButton();
    }
}

function phoneValidator(element) {
    if (element.value.length === 0) {
        redBorder(element);
        disableButton();
    } else if (!element.value.match(phoneValidation)) {
        redBorder(element);
        disableButton();
    } else {
        greenBorder(element);
        disableButton();
    }
}

function passwordValidator(element) {
    if (element.value.length < 6) {
        redBorder(element);
        disableButton();
    } else {
        greenBorder(element);
        disableButton();
    }
}

function confirmPasswordValidator (element) {
    if(element.value !== Password.value){
        redBorder(element);
        disableButton();
    } else{
        greenBorder(element);
        disableButton();
    }
}

function genderValidator(element) {
    if (element.value === "") {
        redBorder(element);
        disableButton();
    } else {
        greenBorder(element);
        disableButton();
    }
}

function roleValidator(element) {
    if (element.value === "") {
        redBorder(element);
        disableButton();
    } else {
        greenBorder(element);
        disableButton();
    }
}



Firstname.addEventListener('input' ,() => firstLastNameValidator(Firstname));
Lastname.addEventListener('input' , () => firstLastNameValidator(Lastname));
Email.addEventListener('input' , () => emailValidator(Email));
Gender.addEventListener('input' , () => genderValidator(Gender));
Password.addEventListener('input' , () => passwordValidator(Password));
ConfirmPassword.addEventListener('input' , () => confirmPasswordValidator(ConfirmPassword));
Role.addEventListener('input' , ()=> roleValidator(Role));
Username.addEventListener('input' , () => firstLastNameValidator(Username));