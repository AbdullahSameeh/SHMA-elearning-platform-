const signUpBtn = document.querySelector('#sign-up');

const signUpHandler = async () => {
    const username = document.querySelector('#sign-up-username').value;
    const password = document.querySelector('#sign-up-password').value;
    const confirmPassword = document.querySelector('#sign-up-confirm-password').value;
    const gender = document.querySelector('#sign-up-gender').value;
    const role = document.querySelector('#sign-up-role').value;
    const firstname = document.querySelector('#sign-up-firstname').value;
    const lastname = document.querySelector('#sign-up-lastname').value;
    const birthdate = document.querySelector('#sign-up-birthdate').value;
    const email = document.querySelector('#sign-up-email').value;

    try {
        const data = {
            userName: username,
            password,
            gender,
            role,
            firstName: firstname,
            lastName: lastname,
            birthdate,
            email
        };

        const response = await fetch('/signup', {
            headers: {
                token: 'token',
                'Content-Type': 'application/json'
            },
            method: 'POST',
            body: JSON.stringify(data)
        });

        const payload = await response.json();

        if (payload.status === 'ok') {
            // success
            window.location.href = '/SignUp.html';
        } else {
            alert(payload.message)
        }
    } catch (error) {
        alert(error.message)
    }

}

signUpBtn.addEventListener('click', signUpHandler);