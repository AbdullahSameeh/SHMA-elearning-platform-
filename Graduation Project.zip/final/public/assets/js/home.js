const signInBtn = document.querySelector('#sign-in-btn');
const profileAnchor = document.querySelector('#profile');
const logoutBtn = document.querySelector('#logout');
console.log(role)

if (token) {
    signInBtn?.setAttribute('style', 'display:none !important');
    if (profileAnchor)
    profileAnchor.href = `/${role === "Teacher" ? "teacher" : "student" }.html?username=${username}`;
    logoutBtn?.addEventListener('click', (e) => {
        e.preventDefault();
        logout();
    });
} else {
    profileAnchor?.setAttribute('style', 'display:none !important');
    logoutBtn?.setAttribute('style', 'display:none !important');
}