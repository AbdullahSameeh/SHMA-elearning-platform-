const courses = document.querySelector('#courses');

async function getAllCourses() {
    try {
        const response = await fetch('/allcourses');
        const payload = await response.json();
        courses.innerHTML = '';
        payload.forEach((course) => {
            const holder = `<div class="col-lg-4 col-md-6 portfolio-item filter-app">
            <img src="${course.backgroundImage}" class="img-fluid" alt="">
            <div class="portfolio-info">
              <h4>${course.courseName || ""}</h4>
              <p>${course.courseCreator || ""}</p>
              <a href="/Courses.html" class="details-link" title="More Details"><i class="bx bx-link"></i></a>
            </div>
          </div>`;
            courses.innerHTML += holder;
        })
        console.log(payload);
    } catch (error) {
        alert(error.message);
    }
}

getAllCourses();