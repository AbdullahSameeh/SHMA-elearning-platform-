const submitBtn = document.querySelector('#inp-submit');
const form = document.querySelector('#form');

form.addEventListener('sumbit', (e) => e.preventDefault());

Date.prototype.toDateInputValue = (function() {
    var local = new Date(this);
    local.setMinutes(this.getMinutes() - this.getTimezoneOffset());
    return local.toJSON().slice(0,10);
});

async function fetchUserInfo() {
    const img = document.querySelector('#img');
    const fullName = document.querySelector('#full-name');
    const role = document.querySelector('#role');
    const firstName = document.querySelector('#inp-firstname');
    const lastName = document.querySelector('#inp-lastname');
    const school = document.querySelector('#inp-school');
    const phone = document.querySelector('#inp-phone');
    const email = document.querySelector('#inp-email');
    const gender = document.querySelector('#inp-gender');
    const imgInp = document.querySelector('#inp-img');
    const birthdate = document.querySelector('#inp-birthdate');
    const address = document.querySelector('#inp-address');

    try {
        const res = await fetch(`/getuserinfo?userName=${username}`);
        const { status, result } = await res.json();
        if (status === 'ok') {
            fullName.textContent = `${result.firstName} ${result.lastName}`;
            role.textContent = result.role;
            img.src = result.img || "https://bootdey.com/img/Content/avatar/avatar7.png";
            firstName.value = result.firstName;
            lastName.value = result.lastName;
            school.value = result.school;
            gender.value = result.gender;
            phone.value = result.phoneNumber || "";
            email.value = result.value || "";
            imgInp.value = result.img || "";
            birthdate.value = new Date(result.birthdate).toDateInputValue();
            address.value = result.address;
        }
    } catch (error) {
        alert(error.message)
    }
}

async function updateProfileHandler() {
    const firstName = document.querySelector('#inp-firstname').value;
    const lastName = document.querySelector('#inp-lastname').value;
    const school = document.querySelector('#inp-school').value;
    const phone = document.querySelector('#inp-phone').value;
    const email = document.querySelector('#inp-email').value;
    const gender = document.querySelector('#inp-gender').value;
    const img = document.querySelector('#inp-img').value;
    const birthdate = document.querySelector('#inp-birthdate').value;
    const address = document.querySelector('#inp-address').value;

    try {
        const data = {
            firstName,
            lastName,
            school,
            phoneNumber: phone,
            email,
            birthdate,
            address,
            gender,
            img
        };
        const res = await fetch(`/updateprofile/${username}`, {
            headers: {
                'Content-Type': 'application/json'
            },
            method: 'PUT',
            body: JSON.stringify(data),
        });
        const payload = await res.json();

        if (payload.status === 'ok') {
            // success
            window.location.href = `/${role === 'Teacher' ? 'teacher' : 'student'}.html?username=${username}`;
        } else {
            alert(payload.message);
        }

    } catch (error) {
        alert(error.message)
    }
}

fetchUserInfo();

submitBtn.addEventListener('click', (e) => {
    e.preventDefault();
    updateProfileHandler();
})