const studentsBar = document.querySelector('#students');
const teachersBar = document.querySelector('#teachers');
const parentsBar = document.querySelector('#parents');
const usersTable = document.querySelector('#users');
const coursesTable = document.querySelector('#courses');
const logoutBtn = document.querySelector('#logout');

async function updateBar() {
    try {
        const response = await fetch('/user-count-per-role');
        const payload = await response.json();
        if (payload.status === 'ok') {
            const total = (payload.students + payload.teachers + payload.parents) || 1;
            studentsBar.style.width = `${100 * payload.students / total}%`;
            teachersBar.style.width = `${100 * payload.teachers / total}%`;
            parentsBar.style.width = `${100 * payload.parents / total}%`;
        } else {
            alert(payload.message);
        }
    } catch (error) {
        alert(error.message);
    }
}

async function deleteUser(id, username) {
    try {
        await fetch(`/deleteuser/${id}`, { method: 'delete' });
        fetchUsersTable();
        alert(`${username} has been deleted`);
    } catch (error) {
        alert(error.message);
    }
}

async function deleteCourse(courseName) {
    try {
        await fetch(`/deletecourse/${courseName}`, { method: 'delete' });
        fetchCoursesTable();
        alert(`${courseName} has been deleted`);
    } catch (error) {
        alert(error.message);
    }
}

async function fetchUsersTable() {
    try {
        const response = await fetch('/getallusers');
        const payload = await response.json();
        usersTable.innerHTML = '';

        payload.forEach((user, index) => {
            const template = `
                <tr>
                    <td>${index + 1}</td>
                    <td>${user.firstName}</td>
                    <td>${user.lastName}</td>
                    <td>${user.role}</td>
                    <td>${user.userName}</td>
                    <td><button type="button" class="btn btn-info" onClick="deleteUser('${user._id}', '${user.userName}')">Delete</button></td>
                </tr>
            `;
            usersTable.innerHTML += template;
        });
    } catch (error) {
        alert(error.message);
    }
}

async function fetchCoursesTable() {
    try {
        const response = await fetch('/allcourses');
        const payload = await response.json();
        const status = ['success', 'info', 'warning', 'danger'];
        coursesTable.innerHTML = '';

        payload.forEach((course, index) => {
            const template = `
                <tr class="${status[index % status.length]}">
                    <td>${index + 1}</td>
                    <td>${course.courseName}</td>
                    <td><button type="button" class="btn btn-info" onClick="deleteCourse('${course.courseName}')">Delete</button></td>
                </tr>
            `;
            coursesTable.innerHTML += template;
        });
    } catch (error) {
        alert(error.message);
    }
}


fetchUsersTable();
fetchCoursesTable();
updateBar();
logoutBtn.addEventListener('click', logout);

