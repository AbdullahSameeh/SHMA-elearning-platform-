const mongoose = require("mongoose");
let adminSchema = new mongoose.Schema(
  {
    firstName: { type: String, default: null },
    lastName: { type: String, default: null },
    gender: { type: String, default: null },
    userName: { type: String, unique: true, required: true },
    password: { type: String, required: true },
  },
  { collection: "admins" }
);

let adminModel = mongoose.model("admins", adminSchema);
module.exports = { adminModel };
