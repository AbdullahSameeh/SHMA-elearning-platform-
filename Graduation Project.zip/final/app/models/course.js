const mongoose = require("mongoose");
// this is the schema of the course, it can have either a pdf file uploaded or
// a link to a youtube video for example
// but you will have to handle the logic of choosing either in the frontend 
let courseSchema = new mongoose.Schema({
    courseName: { type: String, default: null },
    courseLink: { type: String, default: null },
    coursePDF: { type: String, default: "" },
    courseCreator: { type: String, default: null },
    backgroundImage: { type: String, default: null },
    creatorIntro: { type: String, default: null },
    creatorPhoto: { type: String, default: null },
},
    { collection: "courses" }
);
let courseModel = mongoose.model("courses", courseSchema);
module.exports = { courseModel };
// the easier thing to do here is to send the id of the course creator
// in case you want to have it included, then since you have the id of the course creator, you can get their data via a request to the server 
