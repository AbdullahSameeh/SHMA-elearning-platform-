const mongoose = require("mongoose");
let userSchema = new mongoose.Schema(
  {
    firstName: { type: String, default: null },
    lastName: { type: String, default: null },
    role: { type: String, default: null },
    gender: { type: String, default: null },
    userName: { type: String, unique: true, required: true },
    email: { type: String, default: null },
    password: { type: String, required: true },
    phoneNumber: { type: Number, default: 0000000000 },
    school: { type: String, default: null },
    img: { type: String, default: "" },
    address: { type: String, default: null },
    birthdate: { type: Date, default: null }
  },
  { collection: "users" }
);

let userModel = mongoose.model("users", userSchema);
module.exports = { userModel };
