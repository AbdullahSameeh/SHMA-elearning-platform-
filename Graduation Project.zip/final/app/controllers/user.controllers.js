const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const { userModel } = require("../models/user");

// a random value just as a signature
const JWT_SECRET = "akh@!apf3++4%^*W#V#45e5d%^vv@#4";

// for authorization
const checkIdentity = (token) => {
  try {
    const user = jwt.verify(token, JWT_SECRET);
    const _id = user.id;
    return _id;
  } catch {
    //console.log("not authenticated!")
    return false;
  }
};

const main = (req, res) => {
  res.send("Server is up and running ... ");
};

// get user info by username since it is the main identifier
const getUserInfo = async (req, res) => {
  const userName = req.query.userName;
  userModel.findOne({ userName }, (err, result) => {
    if (err) {
      res.send({ message: "user does not exist." });
    } else {
      if (result === null || result.length == 0) {
        res.send({ user: "user does not exist" });
      } else {
        res.send({ status: 'ok', result });
      }
    }
  });
};
const signup = async (req, res) => {
  const { userName, password } = req.body;

  userModel.findOne({ userName }, (err, result) => {
    if (err) {
      res.status(404).send("something wrong happened!");
    } else {
      if (result === null || result.length === 0) {
        bcrypt.hash(password, 2).then((pw) => {
          let newUser = new userModel({ ...req.body, password: pw });
          newUser.save();
          res.send({ status: 'ok', newUser });
        });

      } else {
        res.send({ message: "user already exists!" });
      }
    }
  });
};

// sending the username along with the token if login is successful
const login = async (req, res) => {
  const { userName, password } = req.body;
  const user = await userModel.findOne({ userName }).lean();
  if (!user) {
    return res.send({ message: "User does not exist!" });
  } else {
    if (await bcrypt.compare(password, user.password)) {
      const token = jwt.sign(
        {
          id: user._id,
          email: user.email,
          username: user.userName
        },
        JWT_SECRET
      );
      return res.send({ status: "ok", data: { token, userName, role: user.role } });
    } else {
      res.send({ message: "Invalid email address and/or password!" });
    }
  }
};

const auth = async (req, res) => {
  const { token } = req.body;
  const _id = checkIdentity(token);
  const user = await userModel.findOne({ _id });
  res.send(user);
};

// getting all users
const getAllUsers = async (req, res) => {
  const users = await userModel.find({});
  res.send(users);
};
// update profile
const updateProfile = async (req, res) => {
  const { userName } = req.params;
  console.log(req.body);
  userModel.findOneAndUpdate(
    { userName },
    { ...req.body },
    (err, result) => {
      if (err) {
        res.send({ message: err.message });
      } else {
        res.send({ status: 'ok', result });
      }
    }
  );
};

const updateProfilePic = async (req, res) => {
  console.log(req.file.filename);
  const img = req.file.filename;
  const { userName } = req.body;
  userModel.findOneAndUpdate({ userName }, { img: img }, (err, result) => {
    if (err) {
      res.status(404);
    } else {
      res.send(result);
    }
  });
};

const deleteUser = (req, res) => {

  userModel.findByIdAndRemove(req.params.id, (err) => {
    if(err){
        res.send(err);
    } else {
        getAllUsers(req, res);
    }
 });
};
module.exports = {
  main,
  signup,
  login,
  auth,
  updateProfile,
  getUserInfo,
  getAllUsers,
  updateProfilePic,
  deleteUser
};
