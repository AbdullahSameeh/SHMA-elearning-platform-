const { courseModel } = require("../models/course");

const addCourse = async (req, res) => {
  try {
    const course = await courseModel.find({courseName: req.body.courseName});
    if (course.length) {
      return res.send({message: 'course name is taken!'});
    }

    let newCourse = new courseModel({ ...req.body });
    newCourse.save();
    res.send({status: 'ok', newCourse});
  } catch (error) {
    res.send({ message: error.message });
  }
};

const addPDF = async (req, res) => {
  console.log(req.file.filename);
  const coursePDF = req.file.filename;
  const { courseName } = req.body;
  courseModel.findOneAndUpdate(
    { courseName },
    { coursePDF: coursePDF },
    (err, result) => {
      if (err) {
        res.status(404);
      } else {
        res.send(result);
      }
    }
  );
};

const updateCourse = async (req, res) => {
  const { courseName } = req.params;
  courseModel.findOneAndUpdate(
    { courseName },
    { ...req.body },
    (err, result) => {
      if (err) {
        res.status(404);
      } else {
        res.send(result);
      }
    }
  );
};

const getAllCourses = async (req, res) => {
  const courses = await courseModel.find({});
  res.send(courses);
};

const deleteCourse = async (req, res) => {
  const { courseName } = req.params;
  courseModel.findOneAndDelete({ courseName }, (err, result) => {
    if (err) {
      res.send("course does not exist or is deleted");
    } else {
      res.send(result);
    }
  });
};
const getCourseInfo = async (req, res) => {
  const { courseName } = req.query;
  courseModel.findOne({ courseName }, (err, result) => {
    if (err) {
      res.send({message: "course not found"});
    } else {
      res.send({status: 'ok', result});
    }
  });
};
module.exports = {
  addCourse,
  addPDF,
  updateCourse,
  getAllCourses,
  deleteCourse,
  getCourseInfo
};
