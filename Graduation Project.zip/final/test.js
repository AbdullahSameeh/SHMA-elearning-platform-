
// here we are just referening the input fields and the form that handles editing the user profile page
// the sample form is found in "test.html", I have created a form that accepts a file and a user name just as an example
const button = document.getElementById("btn")
const img = document.getElementById("img")
const form = document.getElementById("myform")
const nameInput = document.getElementById("name")
// here we are ingoring the default behaviour of the form and adding an event listener to the button
// so that it sends a request to the server with the data in the user profile edit page because we do not want 
// the user to be redirected to a different page which does not make sense
button.onclick = function () {
    // here you get the values entered in the edit profile page
    const nameData = nameInput.value
    const imageFile = img.files[0];
    // create a new formData object
    const fd = new FormData();
    // append the first name, profile image, last name, age, school and so on here 
    fd.append("image", imageFile);
    fd.append("userName", "Robert")
    // user fetch or axios to send the request to the server then handle the request
    // here the request does not have to return a specific thing, but as long as there is no error, 
    // you can just assume that the profile data has been saved successfully and you have to redirect the user 
    // to another page like the main page for instance
    // you can use the async await syntax instead for handling promises if you need to user the values returned in the request
    fetch('http://localhost:8080/updateprofileimage/', {
        method: 'POST',
        body: fd
    })
    .then(res => res.data)
    .then(json => console.log(json))
    .catch(err => console.error(err))
    // here I am just console logging the values, but you can do whatever you want with the data instead
}